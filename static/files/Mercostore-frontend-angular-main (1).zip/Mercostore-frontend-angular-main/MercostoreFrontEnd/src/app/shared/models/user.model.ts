export class Usuario {
    constructor(
        public Usuario: string,
        public Senha: string
    ) {}
}